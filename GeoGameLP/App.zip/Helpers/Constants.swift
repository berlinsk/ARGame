import Foundation

struct Constants {
    static let GOOGLE_MAPS_API_KEY = "AIzaSyAVOG0fXGR1ujmiQypuiUsxApH71bu3c3U"
}
