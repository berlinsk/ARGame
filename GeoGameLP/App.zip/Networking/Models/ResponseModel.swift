import Foundation

protocol ResponseModel: Decodable {
    
}
