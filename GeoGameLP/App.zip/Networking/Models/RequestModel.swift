import Foundation

protocol RequestModel: Encodable {
    
}
